---
name: Campus-Cool
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#464554'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0ef'
  outline: '#767586'
  outline-variant: '#c7c4d7'
  surface-tint: '#494bd6'
  primary: '#4648d4'
  on-primary: '#ffffff'
  primary-container: '#6063ee'
  on-primary-container: '#fffbff'
  inverse-primary: '#c0c1ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#825100'
  on-tertiary: '#ffffff'
  tertiary-container: '#a36700'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e5e2e1'
  vibrant-indigo: '#6366F1'
  fresh-mint: '#10B981'
  sunny-amber: '#F59E0B'
  error-red: '#F44336'
  surface-bg: '#F5F5F5'
  surface-card: '#FFFFFF'
  border-subtle: '#E0E0E0'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system for this student-to-student marketplace is built on the narrative of **Campus-Cool**. It bridges the gap between the structured world of academia and the high-energy, fast-paced nature of student life. The brand personality is energetic, trustworthy, and community-driven, aiming to evoke a sense of safety within a local peer-to-peer ecosystem.

The visual style is a **Modern-Corporate hybrid with High-Contrast influences**. It utilizes expansive white space and a "Material-Adjacent" depth model, but injects youthful vitality through vibrant saturated accents and "squishy" soft-rounded geometry. The aesthetic is professional enough to handle financial transactions while remaining approachable enough for a casual dorm-room trade.

## Colors
The palette centers on **Vibrant Indigo**, a color that conveys both the energy of a startup and the stability of an institution. **Fresh Mint** is used strategically for trust-building elements (verified badges, successful sales), while **Sunny Amber** highlights urgency and value (hot deals, price drops).

The default mode is **Light**, utilizing a clean `#F5F5F5` background to allow product imagery to stand out. High-contrast neutral tones ensure that the interface remains legible even in high-glare outdoor campus environments. Use secondary and tertiary colors sparingly—primarily for status indicators and promotional highlights—to maintain the primary brand identity.

## Typography
The system employs a sophisticated sans-serif pairing. **Geist** is used for high-level display and headlines to provide a technical, modern edge. **Inter** handles all functional UI, body copy, and labels, ensuring maximum readability across different device densities.

Hierarchy is established through weight and tight tracking in headlines. For mobile devices, top-level headlines scale down to prevent awkward line breaks in product titles. Labels use a slightly heavier weight (600) to distinguish interactive elements from static body text.

## Layout & Spacing
This design system utilizes a **12-column fluid grid** for desktop and a **4-column grid** for mobile. The rhythm is governed by a strict 4px base unit. 

- **Desktop:** 40px external margins with 24px gutters for section layouts.
- **Mobile:** 16px external margins to maximize screen real estate for product browsing.

Padding within cards and containers should default to `md` (16px) for a balanced, breathable feel. Vertical rhythm between sections should use `xl` (40px) to create clear mental breaks between different marketplace categories.

## Elevation & Depth
The system uses **Ambient Shadows** to create a natural sense of hierarchy. Instead of flat borders, depth is the primary signifier of interactable surfaces.

- **Level 1 (Default Cards):** A soft, diffused shadow (`0px 4px 12px rgba(0, 0, 0, 0.08)`) makes product tiles appear to float slightly above the global background.
- **Level 2 (Active/Hover):** On hover, shadows expand (`0px 8px 24px rgba(0, 0, 0, 0.12)`) to provide tactile feedback.
- **Level 3 (Overlays):** Modals and drawers use the highest elevation (`0px 12px 32px rgba(0, 0, 0, 0.15)`) combined with a 50% opacity neutral-tone scrim to focus the user's attention.

## Shapes
Shapes are defined by **soft, approachable roundedness**. This helps mitigate the "stiffness" of a marketplace and makes the community feel more welcoming. 

Consistent with the `Rounded` setting (8px base), product cards and thumbnails should lean into the `rounded-lg` (16px) or `rounded-xl` (24px) territory to create the "Campus-Cool" signature look. Buttons and input fields remain at a standard 8px to ensure they feel like sturdy, functional tools.

## Components
- **Buttons:** Primary buttons use `Vibrant Indigo` with white text. They should have a subtle 2px press-down effect rather than a simple color change. Secondary buttons use a low-opacity Indigo tint.
- **Product Cards:** The cornerstone of the marketplace. Cards should have a white background, `rounded-lg` (16px) corners, and Elevation Level 1. Content is stacked vertically: Image > Title > Price > Location Tag.
- **Chips:** Used for categories (e.g., "Textbooks", "Electronics"). Use a light gray fill with `rounded-pill` geometry. Active states switch to a `Vibrant Indigo` fill.
- **Input Fields:** Minimalist style with a 1px `border-subtle`. On focus, the border transitions to 2px `Vibrant Indigo`.
- **Verified Badges:** Small circular icons using `Fresh Mint` to denote student-identity verification, placed adjacent to seller names.
- **Navigation:** A persistent bottom navigation bar on mobile with high-contrast icons (2px stroke) and a 12px blur backdrop to maintain legibility over scrolling content.